from IPython.parallel.client import Client

client = Client()
