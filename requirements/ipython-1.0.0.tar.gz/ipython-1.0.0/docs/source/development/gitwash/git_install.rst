.. _install-git:

=============
 Install git
=============

Overview
========

================ =============
Debian / Ubuntu  ``sudo apt-get install git-core``
Fedora           ``sudo yum install git-core``
Windows          Download and install msysGit_
OS X             Use the git-osx-installer_
================ =============

In detail
=========

See the git_ page for the most recent information.

Have a look at the github_ install help pages available from `github help`_

There are good instructions here: http://book.git-scm.com/2_installing_git.html

.. include:: git_links.txt
