.. _config_index:

===============================
Configuration and customization
===============================

.. toctree::
   :maxdepth: 2

   overview
   extensions/index
   ipython
   integrating
   editors
   inputtransforms
   old
