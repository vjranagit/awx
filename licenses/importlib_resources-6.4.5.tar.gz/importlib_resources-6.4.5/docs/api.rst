=============
API Reference
=============

``importlib_resources`` module
------------------------------

.. automodule:: importlib_resources
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: importlib_resources.abc
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: importlib_resources.readers
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: importlib_resources.simple
   :members:
   :undoc-members:
   :show-inheritance:
