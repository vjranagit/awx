:orphan:

Psycopg documentation build
===========================

Quick start::

    make env
    source .venv/bin/activate
    make serve

and connect to <http://localhost:8000>.
