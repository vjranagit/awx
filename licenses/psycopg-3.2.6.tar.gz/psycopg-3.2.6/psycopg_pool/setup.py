#!/usr/bin/env python3
"""
PostgreSQL database adapter for Python - Connection Pool
"""

# Copyright (C) 2020 The Psycopg Team

from setuptools import setup

setup()
