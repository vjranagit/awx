
NAME='ugreen'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['ugreen']
