.. image:: https://img.shields.io/pypi/v/backports.tarfile.svg
   :target: https://pypi.org/project/backports.tarfile

.. image:: https://img.shields.io/pypi/pyversions/backports.tarfile.svg

.. image:: https://github.com/jaraco/backports.tarfile/actions/workflows/main.yml/badge.svg
   :target: https://github.com/jaraco/backports.tarfile/actions?query=workflow%3A%22tests%22
   :alt: tests

.. image:: https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/charliermarsh/ruff/main/assets/badge/v2.json
    :target: https://github.com/astral-sh/ruff
    :alt: Ruff

.. .. image:: https://readthedocs.org/projects/backportstarfile/badge/?version=latest
..    :target: https://backportstarfile.readthedocs.io/en/latest/?badge=latest

.. image:: https://img.shields.io/badge/skeleton-2024-informational
   :target: https://blog.jaraco.com/skeleton
