v1.2.0
======

Features
--------

- Remove shebang. (#4)
- Synced with python/cpython@f912e5a2f6.


v1.1.1
======

Bugfixes
--------

- Declare the backports namespace package. (#5)


v1.1.0
======

Features
--------

- Backported tests from CPython. (#2)


Bugfixes
--------

- Fixed a bug in _proc_gnulong on Python 3.8 where removesuffix was used.


v1.0.0
======

- Initial release based on tarfile from Python 3.12.2.
