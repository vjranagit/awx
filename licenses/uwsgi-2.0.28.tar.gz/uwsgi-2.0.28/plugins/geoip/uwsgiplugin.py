NAME='geoip'

CFLAGS = []
LDFLAGS = []
LIBS = ['-lGeoIP']

GCC_LIST = ['geoip']

